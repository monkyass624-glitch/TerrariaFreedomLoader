# رفع المشروع من هاتف Android باستخدام موقع GitHub

1. فك ضغط `FreedomLoader-Stage2.zip` على هاتفك.
2. افتح github.com وسجّل الدخول.
3. اضغط **New repository**، وسمّه `TerrariaFreedomLoader`.
4. أنشئ المستودع، ثم من صفحة المستودع اضغط **Add file → Upload files**.
5. ارفع محتويات مجلد `FreedomLoader-Stage2`، وليس ملف ZIP نفسه.
6. افتح تبويب **Actions**، واختر **Build Freedom Loader runtime inspector (ARM64)**.
7. اضغط **Run workflow**.
8. بعد انتهاء البناء، افتح نتيجة التشغيل ونزّل ملف artifact باسم `freedom-runtime-inspector-arm64`.

ملاحظة: الملف الناتج `.so` وليس APK، ولا يعمل عند فتحه كتطبيق مستقل. يجب لاحقاً تحميله داخل عملية Terraria نفسها من خلال تكامل Freedom Loader مع تشغيل التطبيق. لا تفعّل Hook التجريبي قبل تأكيد مطابقة بيانات runtime.
