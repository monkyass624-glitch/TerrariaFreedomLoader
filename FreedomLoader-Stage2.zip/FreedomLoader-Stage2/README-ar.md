# Terraria Freedom Loader — المرحلة الثانية

**الهدف:** الانتقال من التحليل الثابت لنسخة Terraria Mobile 1.4.5.6.4 ARM64 إلى التحقق من نفس التواقيع داخل IL2CPP وقت التشغيل.

## ما أُنجز في هذه المرحلة

1. تحديد MetadataRegistration المرشح في هذه المكتبة عند RVA `0x2F32510`.
2. التحقق من مصفوفة أنواع IL2CPP: 22,999 مؤشر نوع، وكلها تشير إلى سجلات `Il2CppType` قابلة للقراءة.
3. ربط TypeIndex بأسماء الأنواع، بما في ذلك `System.Int32`, `System.Single`, `System.Boolean`, `Microsoft.Xna.Framework.Vector2` وأنواع Terraria.
4. استخراج تواقيع 39 overload مختارة من أصناف Main وPlayer وNPC وProjectile وWorldGen وItem وNetMessage وNetplay.
5. استخراج 3,038 إزاحة حقل خامة من أصناف اللعبة الأساسية.
6. إضافة مكتبة C++ للقراءة فقط: تستدعي واجهات IL2CPP المصدّرة عبر `dlsym`، تنتظر تهيئة الـ Domain، وتبحث عن `Assembly-CSharp`، ثم تسجل توقيعات الدوال ومؤشر MethodInfo الأول للمقارنة مع RVA.
7. إضافة GitHub Actions لبناء ملف `.so` بمعمارية `arm64-v8a` دون الحاجة إلى كمبيوتر محلي.
8. تجهيز Hook تجريبي رصدي لـ `Terraria.Player.ResetEffects`، لكنه **معطّل افتراضياً** ولا يثبت نفسه إلا عند بناء الخيار التجريبي، وبعد اجتياز فحوص التوقيع ومؤشر MethodInfo وبصمة تعليمات ARM64.

## مثال من التواقيع المستخرجة

- `Terraria.Player.ResetEffects() -> System.Void`
- `Terraria.Player.UpdateBuffs(i: System.Int32) -> System.Void`
- `Terraria.Player.Hurt(damageSource: Terraria.DataStructures.PlayerDeathReason, Damage: System.Int32, hitDirection: System.Int32, pvp: System.Boolean, quiet: System.Boolean, Crit: System.Boolean, cooldownCounter: System.Int32, dodgeable: System.Boolean) -> System.Double`
- `Terraria.NPC.SetDefaults(Type: System.Int32, spawnparams: Terraria.NPCSpawnParams) -> System.Void`
- `Terraria.Projectile.NewProjectile(...) -> System.Int32` (11 و13 وسيطاً حسب overload)
- `Terraria.WorldGen.PlaceTile(i: System.Int32, j: System.Int32, Type: System.Int32, mute: System.Boolean, forced: System.Boolean, plr: System.Int32, style: System.Int32) -> System.Boolean`

راجع `analysis/terraria_method_signatures_resolved.csv` للتفاصيل الكاملة.

## بناء مكتبة ARM64 من GitHub

1. أنشئ مستودع GitHub جديداً وارفع محتويات هذا المجلد.
2. افتح تبويب Actions.
3. اختر **Build Freedom Loader runtime inspector (ARM64)** ثم **Run workflow**.
4. بعد انتهاء البناء، نزّل artifact باسم `freedom-runtime-inspector-arm64`.

أو ابنها محلياً باستخدام Android NDK وCMake من خلال `runtime-inspector/CMakeLists.txt`.

### Hook تجريبي اختياري بعد التحقق

الخيار `FREEDOM_ENABLE_EXPERIMENTAL_HOOK` معطّل افتراضياً. لا تفعّله الآن لمجرد نجاح البناء؛ يجب أولاً تشغيل الفاحص داخل اللعبة وقراءة Logcat للتأكد من جميع شروط `hook-validation-manifest.json`. عند تفعيل الخيار في CMake، يجلب المشروع Dobby ويبني Hook رصدياً لـ `Player.ResetEffects` يمرر التنفيذ إلى الدالة الأصلية. واجهة Dobby ودمجه مع Android موثقان في مستودعه الرسمي ودليل البدء لـ Android.

## تحذير استخدام مهم

- المكتبة الناتجة **ليست APK** وليست لودر مودات مكتمل.
- أداة الفحص لا تغيّر اللعبة ولا تثبّت Hook؛ إنها تقرأ الـ runtime reflection وتكتب النتائج في Android logcat.
- لا بد من تحميل هذه المكتبة داخل **عملية Terraria نفسها** كي ترى `libil2cpp.so`. تشغيلها كتطبيق مستقل لن يعطيها وصولاً إلى Domain اللعبة.
- عناوين RVA تخص ملف `libil2cpp.so` الذي فُحص فقط، ولا تستخدمها على إصدار آخر أو build مختلف.
- لا نفعّل أي Hook افتراضياً. يوجد Hook رصدي تجريبي لـ `Player.ResetEffects`، لكنه يرفض التثبيت ما لم يطابق runtime: اسم الصنف، اسم الدالة، عدد المعاملات، نوع الإرجاع، كونها instance، مؤشر MethodInfo مع `base + RVA`، وأول 16 بايت من الدالة. راجع `analysis/hook-validation-manifest.json`.
- لا يمكن اختبار الـ Hook فعلياً قبل تحميل المكتبة داخل عملية Terraria نفسها. البناء المحلي الذي تحققنا منه هنا كان host smoke-test، وليس ARM64 Android.
- الملف الحالي يركز على `arm64-v8a`. لم نبنِ بعد دعم `armeabi-v7a`.

## أين وصلنا؟

التحليل الثابت صار يحتوي تواقيع وأنواعاً وإزاحات حقول أولية. المرحلة التالية بعد تشغيل الفاحص داخل Terraria هي استخدام النتائج المطابقة لاختيار Hook رصدي لا يغير سلوك اللعبة، ثم بناء محمّل المودات وبيئة C#.
